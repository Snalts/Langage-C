int saisi_joueur();

int saisi_ia(int somme);

int strategie_ia(int somme);