int point(int tab_valeurs[6]);

void affichage_de(int tab_valeurs[6]);

void jets_de(int tab_valeurs[6]);