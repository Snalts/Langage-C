#include <stdio.h>
#include <stdlib.h>
#include "exo1_fonction.h"

#define NB_PERSONNE_DEPART 3
