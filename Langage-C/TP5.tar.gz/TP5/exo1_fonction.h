#include <stdio.h>
#include <stdlib.h>

void affichage(int rives[]);
void envoyer(int rives[],int); 
