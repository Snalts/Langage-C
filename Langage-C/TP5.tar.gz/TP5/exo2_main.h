#include <stdio.h>
#include <stdlib.h>
#include "exo2_fonction.h"

#define TAILLE_TAB 7
